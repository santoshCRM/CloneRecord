﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Xml;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Workflow;
namespace Approvalconfigurationcore
{
    public class RejectWorkflow : CodeActivity
    {
        [Input("User")]
        [ReferenceTarget("systemuser")]
        public InArgument<EntityReference> User { get; set; }

        [Input("Team")]
        [ReferenceTarget("team")]
        public InArgument<EntityReference> Team { get; set; }

        [Output("IsRejected")]
        [RequiredArgument]
        public OutArgument<bool> IsRejected { get; set; }

       
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService traceservice = executionContext.GetExtension<ITracingService>();
          
            try
            {
                traceservice.Trace("Workflow started");
                IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (User.Get(executionContext) == null && Team.Get(executionContext) == null)
                {
                    IsRejected.Set(executionContext, true);
                }
                if (User.Get(executionContext) != null)
                {
                    traceservice.Trace("Check user");
                    //Check user
                    if (User.Get(executionContext).Id == context.UserId)
                        IsRejected.Set(executionContext, true);
                }
                else if (Team.Get(executionContext) != null)
                {
                    traceservice.Trace("get user team");
                    // get user team
                    EntityCollection teams = getTeam(context.UserId, service);
                    if (teams.Entities.Count > 0)
                    {
                        traceservice.Trace("Check team");
                        foreach (Entity team in teams.Entities)
                        {
                            if (team.Id == Team.Get(executionContext).Id)
                                IsRejected.Set(executionContext, true);
                        }
                    }
                }
                if (IsRejected.Get(executionContext) != true)
                {
                    IsRejected.Set(executionContext, false);
                    traceservice.Trace("You are not authorize for this action.");
                  

                }

            }
            catch (Exception ex)
            {
                traceservice.Trace("Error occured: " + ex.ToString());
                throw new InvalidPluginExecutionException(ex.ToString());

            }


        }

        internal EntityCollection getTeam(Guid systemUserId, IOrganizationService service)
        {
            string fetchXML =
                "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>"
  + "<entity name='team'>"
    + "<attribute name='name' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='teamid' />"
    + "<attribute name='teamtype' />"
    + "<order attribute='name' descending='false' />"
    + "<link-entity name='teammembership' from='teamid' to='teamid' visible='false' intersect='true'>"
      + "<link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='ac'>"
        + "<filter type='and'>"
           + "<condition attribute='systemuserid' operator='eq' uitype='systemuser'  value='{" + systemUserId + "}' />"
        + "</filter>"
      + "</link-entity>"
    + "</link-entity>"
  + "</entity>"
+ "</fetch>";

            RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
            {
                Query = new FetchExpression(fetchXML)
            };

            EntityCollection returnCollection = ((RetrieveMultipleResponse)service.Execute(fetchRequest1)).EntityCollection;
            return returnCollection;


        }
    }
}
