﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
namespace Approvalconfigurationcore
{
    public class GetFirstStep : CodeActivity
    {
        [Input("WorkflowTemplate")]
        [RequiredArgument]
        [ReferenceTarget("sav_workflowtemplate")]
        public InArgument<EntityReference> WorkflowTemplate { get; set; }

        [Output("WorkflowTemplateTransit")]
        [RequiredArgument]
        [ReferenceTarget("sav_workflowtemplatetransit")]
        public OutArgument<EntityReference> WorkflowTemplateTransit { get; set; }


        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService traceService = executionContext.GetExtension<ITracingService>();
            try
            {

                IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                traceService.Trace("Workflow Started");
                if (service != null && WorkflowTemplate != null)
                {
                    //Get WorkflowTemplateTransit based on WorkflowTemplate
                    QueryExpression query = new QueryExpression("sav_workflowtemplatetransit");
                    query.ColumnSet.AllColumns = true;
                    query.Criteria.AddCondition(new ConditionExpression("sav_workflowtempalate", ConditionOperator.Equal, WorkflowTemplate.Get(executionContext).Id));
                    traceService.Trace("Condition 1 added");
                    query.Criteria.AddCondition(new ConditionExpression("sav_name", ConditionOperator.Equal, "1"));
                    traceService.Trace("Condition 2 added");
                    EntityCollection collection = service.RetrieveMultiple(query);
                    traceService.Trace("EntityCollection retrived");
                    if (collection.Entities.Count() > 0)
                    {
                        WorkflowTemplateTransit.Set(executionContext, collection.Entities[0].ToEntityReference());
                        traceService.Trace("WorkflowTemplateTransit value set");

                    }


                }
                // throw new InvalidPluginExecutionException("test");
            }
            catch (Exception ex)
            {
                traceService.Trace("Error occured: " + ex.ToString());
                throw new InvalidPluginExecutionException("test");

            }

        }
    }
}
