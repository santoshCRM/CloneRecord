﻿///script/Case.js
function filterSubGrid() {
    var workflowTemplatetValue = Xrm.Page.getAttribute("sav_workflowtemplate").getValue(); //field to filter by 
    var workflowTemplatetGrid = Xrm.Page.getControl("WorkflowTemplateTransit");//grid to filter
    if (workflowTemplatetGrid == null) { //make sure the grid has loaded 
        setTimeout(function () { filterSubGrid(); }, 2000); //if the grid hasn’t loaded run this again when it has 
        return;
    }


    var workflowTemplatetValueid = "00000000-0000-0000-0000-000000000000"; //if filter field is null display nothing 
    if (workflowTemplatetValue != null) {
        workflowTemplatetValueid = workflowTemplatetValue[0].id;
    }

    //fetch xml code which will retrieve all the accounts related to the contact 
    var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
"  <entity name='sav_workflowtemplatetransit'>" +
"    <attribute name='sav_name' />" +
"    <attribute name='sav_workflowtempalate' />" +
"    <attribute name='sav_workflowstep2' />" +
"    <attribute name='sav_workflowstep1' />" +
"    <attribute name='sav_approveruser' />" +
"    <attribute name='sav_approverteam' />" +
"    <attribute name='sav_sendemail' />" +
"    <attribute name='sav_workflowtemplatetransitid' />" +
"    <order attribute='sav_name' descending='false' />" +
"    <filter type='and'>" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"      <condition attribute='sav_workflowtempalate' operator='eq'  value='" + workflowTemplatetValueid + "' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
    workflowTemplatetGrid.getGrid().setParameter("fetchXml", fetchXml);
    workflowTemplatetGrid.refresh();
}

function WT_Approval()
{
    CurrentWorkflowStep = Xrm.Page.getAttribute("sav_currentworkflowstep").getValue();
    if (CurrentWorkflowStep == null) {
        Xrm.Utility.alertDialog("No steps found for this workflow.", null);
        return;
    }
    WorkflowApprovalStatus = Xrm.Page.getAttribute("sav_workflowapprovalstatus").getText();
    if (WorkflowApprovalStatus == "Approved")
    {
        Xrm.Utility.alertDialog("Workflow already approved", null);
        return;
    }
    savSDKCollection.callApproveRequest();

}
function WT_Rejection()
{
    CurrentWorkflowStep = Xrm.Page.getAttribute("sav_currentworkflowstep").getValue();
    if (CurrentWorkflowStep == null) {
        Xrm.Utility.alertDialog("No steps found for this workflow.", null);
        return;
    }
    WorkflowApprovalStatus = Xrm.Page.getAttribute("sav_workflowapprovalstatus").getText();
    if (WorkflowApprovalStatus == "Rejected") {
        Xrm.Utility.alertDialog("Workflow already rejected", null);
        return;
    }
    savSDKCollection.callRejectRequest();
}
var Status;
var savSDKCollection = {
    _getServerUrl: function () {
        var e = "/XRMServices/2011/Organization.svc/web";
        var t = "";
        if (typeof GetGlobalContext == "function") {
            var n = GetGlobalContext();
            t = n.getClientUrl()
        } else {
            if (typeof Xrm.Page.context == "object") {
                t = Xrm.Page.context.getClientUrl()
            }
            else {
                throw new Error("Unable to access the server URL")
            }
        }
        if (t.match(/\/$/)) {
            t = t.substring(0, t.length - 1)
        }
        return t + e
    },
    callApproveRequest: function () {
        var caseId = Xrm.Page.data.entity.getId(); caseId = caseId.substring(1, caseId.length - 1);
        var i = "<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>" +
"  <s:Body>" +
"    <Execute xmlns='http://schemas.microsoft.com/xrm/2011/Contracts/Services' xmlns:i='http://www.w3.org/2001/XMLSchema-instance'>" +
"      <request xmlns:a='http://schemas.microsoft.com/xrm/2011/Contracts'>" +
"        <a:Parameters xmlns:b='http://schemas.datacontract.org/2004/07/System.Collections.Generic'>" +
"          <a:KeyValuePairOfstringanyType>" +
"            <b:key>Target</b:key>" +
"            <b:value i:type='a:EntityReference'>" +
"              <a:Id>" + caseId + "</a:Id>" +
"              <a:KeyAttributes xmlns:c='http://schemas.microsoft.com/xrm/7.1/Contracts' />" +
"              <a:LogicalName>incident</a:LogicalName>" +
"              <a:Name i:nil='true' />" +
"              <a:RowVersion i:nil='true' />" +
"            </b:value>" +
"          </a:KeyValuePairOfstringanyType>" +
"        </a:Parameters>" +
"        <a:RequestId i:nil='true' />" +
"        <a:RequestName>sav_Approveworkflow</a:RequestName>" +
"      </request>" +
"    </Execute>" +
"  </s:Body>" +
"</s:Envelope>";

        var errorHandler;
        var s = new XMLHttpRequest;
        var errorHandler;
        s.open("POST", savSDKCollection._getServerUrl(), false);
        s.setRequestHeader("Accept", "application/xml, text/xml, */*");
        s.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
        s.setRequestHeader("SOAPAction", "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute");
        s.onreadystatechange = function () {
            savSDKCollection.SetStateResponse(s, null, errorHandler)
        };
        s.send(i)
    },
    callRejectRequest: function () {
        var caseId = Xrm.Page.data.entity.getId(); caseId = caseId.substring(1, caseId.length - 1);
        var i ="<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>" +
"  <s:Body>" +
"    <Execute xmlns='http://schemas.microsoft.com/xrm/2011/Contracts/Services' xmlns:i='http://www.w3.org/2001/XMLSchema-instance'>" +
"      <request xmlns:a='http://schemas.microsoft.com/xrm/2011/Contracts'>" +
"        <a:Parameters xmlns:b='http://schemas.datacontract.org/2004/07/System.Collections.Generic'>" +
"          <a:KeyValuePairOfstringanyType>" +
"            <b:key>Target</b:key>" +
"            <b:value i:type='a:EntityReference'>" +
"              <a:Id>" + caseId + "</a:Id>" +
"              <a:KeyAttributes xmlns:c='http://schemas.microsoft.com/xrm/7.1/Contracts' />" +
"              <a:LogicalName>incident</a:LogicalName>" +
"              <a:Name i:nil='true' />" +
"              <a:RowVersion i:nil='true' />" +
"            </b:value>" +
"          </a:KeyValuePairOfstringanyType>" +
"        </a:Parameters>" +
"        <a:RequestId i:nil='true' />" +
"        <a:RequestName>sav_RejectWorkflow</a:RequestName>" +
"      </request>" +
"    </Execute>" +
"  </s:Body>" +
"</s:Envelope>";
        var errorHandler;
        var s = new XMLHttpRequest;
        var errorHandler;
        s.open("POST", savSDKCollection._getServerUrl(), false);
        s.setRequestHeader("Accept", "application/xml, text/xml, */*");
        s.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
        s.setRequestHeader("SOAPAction", "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute");
        s.onreadystatechange = function () {
            savSDKCollection.SetStateResponse(s, null, errorHandler)
        };
        s.send(i)
    },
    SetStateResponse: function (e, t, n) {
        if (e.readyState == 4) {
            if (e.status == 200) {
               
                if (window.ActiveXObject || e.responseType == "msxml-document") {//ie
                    if (e.responseXML.getElementsByTagName("b:value").length > 0) {
                        //alert("Workflow is created with Entry No. :-" + e.responseXML.getElementsByTagName("b:value")[0].textContent);
                        Status = e.responseXML.getElementsByTagName("b:value")[0].textContent;
                    }
                }
                else {
                    if (e.responseXML.getElementsByTagName("value").length > 0) {
                        //  alert("Workflow is created with Entry No. :-" + e.responseXML.getElementsByTagName("value")[0].textContent);
                        Status = e.responseXML.getElementsByTagName("value")[0].textContent;
                    }
                    else if (e.responseXML.getElementsByTagName("b:value").length > 0) {
                        Status = e.responseXML.getElementsByTagName("b:value")[0].textContent;
                    }

                }
                if (Status == "false")
                    Xrm.Utility.alertDialog("You are not authorize for this action.", null);
                else if (Status == "true")
                    Xrm.Page.data.refresh();

                if (t != null) { t() }
            } else {
                savSDKCollection._getError(e.responseXML)
            }
        }
    },
    _getError: function (e) {
        btnNameCOLL = null; desc_val = null; entryNo = null;
        var t = "Unknown Error (Unable to parse the fault)"; if (typeof e == "object") {
            try {
                var n = e.firstChild.firstChild; for (var r = 0; r < n.childNodes.length; r++) {
                    var i = n.childNodes[r]; if ("s:Fault" == i.nodeName) {
                        for (var s = 0; s < i.childNodes.length; s++) {
                            var o = i.childNodes[s];
                            if ("faultstring" == o.nodeName) {

                            }
                            if ("faultstring" == o.nodeName
                    ) {
                                t = o.text + " textContent:=" + n.textContent;
                                alert(o.firstChild.data);
                                break
                            }
                        } break
                    }
                }
            } catch (u) { }
        } return new Error(t)
    }
}