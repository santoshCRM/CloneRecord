﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel;
namespace CloneRecords
{
   public class CloneRecord:CodeActivity
   {
       #region variable used
       [Input("SourceEntityType")]
       [RequiredArgument]
       public InArgument<string> SourceEntityType { get; set; }
       [Input("SourceRecordId")]
       [RequiredArgument]
       public InArgument<string> SourceRecordId { get; set; }
       [Input("Exclusivelst")]
       [RequiredArgument]
       public InArgument<string> Exclusivelst { get; set; }
       
       [Output("OutputRecordId")]
       public OutArgument<string> OutputRecordId { get; set; }
       #endregion
       protected override void Execute(CodeActivityContext executionContext)
        {
          
            ITracingService trace = executionContext.GetExtension<ITracingService>();
            trace.Trace("workflow started!!");
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory servicefactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = servicefactory.CreateOrganizationService(context.UserId);

            try
            {
                Entity source = service.Retrieve(SourceEntityType.Get(executionContext), new Guid(SourceRecordId.Get(executionContext)), new Microsoft.Xrm.Sdk.Query.ColumnSet(true));
                trace.Trace("workflow in try block.");
                Entity target = new Entity(SourceEntityType.Get(executionContext));
                string[] str = Exclusivelst.Get(executionContext).Split('|');
                Boolean type = true;
                trace.Trace("source Attributes count: " + source.Attributes.Count().ToString());
                foreach (object obj in source.Attributes)
                {
                    foreach (string str1 in str)
                    {
                        if (((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key.ToString().Contains(str1))
                        {
                            type = false;
                            break;
                        }
                        if (((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key.ToString().Contains(source.LogicalName + "id"))
                        {
                            type = false;
                            break;
                        }
                    }
                    if (type)
                        Setvalue(target, obj);
                    type = true;
                }
                trace.Trace("Attributes set");
               Guid targetid= service.Create(target);
               trace.Trace("target created with Id " + targetid.ToString());

               if (targetid != null)
                   OutputRecordId.Set(executionContext, targetid.ToString());
               else
                   OutputRecordId.Set(executionContext, "00000000-0000-0000-0000-000000000000");
               trace.Trace(OutputRecordId.Get(executionContext));
             
            }
            catch (Exception ex)
            {
                 throw new InvalidPluginExecutionException(ex.ToString()); 
            }
            

        }

        private  void Setvalue(Entity target, object obj)
        {
            string value = ((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value.GetType().Name.ToString();
            if (value == "Boolean")
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = (bool)((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value;
            else if (value == "OptionSetValue")
            {
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = new OptionSetValue(((Microsoft.Xrm.Sdk.OptionSetValue)(((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value)).Value);
            }
            else if (value == "EntityReference")
            {
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = (EntityReference)(((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value);
            }
            else if (value == "Decimal")
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = (Decimal)((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value;
            else if (value == "String")
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = ((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value.ToString();
            else if (value == "Int32")
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = (Int32)((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value;
            else if (value == "Money")
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = new Microsoft.Xrm.Sdk.Money(((Microsoft.Xrm.Sdk.Money)(((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value)).Value);
            else if (value == "DateTime")
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = ((DateTime)((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value);
            else
                target[((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Key] = ((System.Collections.Generic.KeyValuePair<string, object>)(obj)).Value;
        }
    }
}
